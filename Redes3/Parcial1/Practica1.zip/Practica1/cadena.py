import sys


s = "Hola soy ubuntu en esta"
if s.find("is") == -1:
    print "No 'is' here!"
else:
    print "Found 'is' in the string."